package com.example.demo;

public interface Activar {
    void activar();
    void desactivar();
    boolean isActive();
    boolean compareTo(int durancion);

}
