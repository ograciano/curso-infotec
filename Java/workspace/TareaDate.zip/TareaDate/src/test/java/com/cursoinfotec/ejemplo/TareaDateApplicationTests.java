package com.cursoinfotec.ejemplo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TareaDateApplicationTests {

	@Test
	void contextLoads() {
	}

}
