package com.cursoinfotec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoInfotecApplicationTests {

	@Test
	void contextLoads() {
	}

}
