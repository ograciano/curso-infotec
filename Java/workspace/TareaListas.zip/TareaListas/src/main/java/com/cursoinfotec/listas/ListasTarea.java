package com.cursoinfotec.listas;

public class ListasTarea {
	System.out.println('Holamundo');
}
