import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public valor1: number = 1;
  public valor2: number = 1;
  public valor3: number = 1;

  constructor(){
    this.valor1 = this.valorAleatorio();
    this.valor2 = this.valorAleatorio();
    this.valor3 = this.valorAleatorio();
  }

  private valorAleatorio() : number {
    return Math.trunc(Math.random()*6)+1;
  }
}
