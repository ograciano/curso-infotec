import { Component, OnInit } from '@angular/core';
import { ArticuloService } from '../articulo.service';
import { Articulo } from '../interfaces/articulo';

@Component({
  selector: 'app-articulos',
  templateUrl: './articulos.component.html',
  styleUrls: ['./articulos.component.css']
})
export class ArticulosComponent implements OnInit {

  public articulos: Articulo[] = [];
  public codigo: number = 0;
  public descripcion: string = '';
  public precio: number = 0;
  public imagen: string = 'https://m.media-amazon.com/images/I/61Nz8w948OL._AC_SX679_.jpg';
  private index: number = -1;
  public anadir = true;

  constructor(private readonly articuloService: ArticuloService) { }

  ngOnInit(): void {
    this.articulos = this.articuloService.getArticulos();
  }


  private articuloSeleccionado(): Articulo {

    let  articulo: Articulo = {
      codigo: this.codigo,
      descripcion: this.descripcion,
      precio: this.precio,
      img: this.imagen
    };
    return articulo;
  }

  inicializarArticulo(){
    this.codigo = 0;
    this.descripcion = '';
    this.precio = 0;
    this.imagen = 'https://m.media-amazon.com/images/I/61Nz8w948OL._AC_SX679_.jpg'
    this.index = -1;
    this.anadir = true;
  }


  public addArticulo() {
    let articulo = this.articuloSeleccionado();
    if(this.articuloService.existecodigo(articulo.codigo)) return alert('El codido ya existe en la base de datos');
    if(articulo.codigo == 0) return alert('El codigo no puede ser cero')
    this.articuloService.addArticulo(articulo);
    this.inicializarArticulo();
    this.articulos = this.articuloService.getArticulos();
  }

  public modificarArticulo() {
    let articulo = this.articuloSeleccionado();
    if(articulo.codigo == 0) return alert('El codigo no puede ser cero')
    this.articuloService.putArticulo(this.index, articulo);
    this.inicializarArticulo();
    this.articulos = this.articuloService.getArticulos();
  }

  public borrar(index: number) {
    if(confirm('Desea borrar al articulo?')) this.articuloService.deleteArticulo(index);
    this.articulos = this.articuloService.getArticulos();
  }

  public seleccionar(index: number) {
    let articulo = this.articuloService.getArticulo(index);
    this.codigo = articulo.codigo;
    this.descripcion = articulo.descripcion;
    this.precio = articulo.precio;
    this.imagen = articulo.img;
    this.anadir = false;
    this.index = index;

  }

  public ver(index: number) {
    console.log(`proxima pagina con index: ${index}`);
  }



}
