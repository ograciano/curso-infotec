export interface Articulo {
  codigo: number;
  descripcion: string;
  precio: number;
  img: string;
}
