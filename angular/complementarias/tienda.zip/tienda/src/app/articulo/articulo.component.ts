import { Component, OnInit } from '@angular/core';
import { Articulo } from '../interfaces/articulo';
import { ActivatedRoute } from '@angular/router';
import { ArticuloService } from '../articulo.service';

@Component({
  selector: 'app-articulo',
  templateUrl: './articulo.component.html',
  styleUrls: ['./articulo.component.css']
})
export class ArticuloComponent implements OnInit {

  constructor(private readonly route: ActivatedRoute, private readonly articuloService:ArticuloService) { }
  public articulo: Articulo = {
    codigo: 0,
    descripcion: '',
    precio: 0,
    img: ''
  }
  public index: any;

  ngOnInit(): void {
    this.index = this.route.snapshot.paramMap.get('index');
    this.articulo = this.articuloService.getArticulo(this.index)
  }

}
