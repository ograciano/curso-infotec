import { Injectable } from '@angular/core';
import { Articulo } from './interfaces/articulo';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class ArticuloService {

  private articulos: Articulo[] = [];

  constructor(private readonly storageService: StorageService) { }

  addStorage(){
    this.storageService.add('tienda', JSON.stringify(this.articulos));
  }

  getStorage() {
    JSON.parse(this.storageService.get('tienda'))
    ? this.articulos = JSON.parse(this.storageService.get('tienda'))
    : this.articulos = [];
  }

  public addArticulo(articulo: Articulo): void {
    this.articulos.push(articulo);
    this.addStorage();
  }

  public putArticulo(index: number, articulo: Articulo): void {
    this.articulos[index] = articulo;
    this.addStorage();
  }

  public getArticulos(): Articulo[] {
    this.getStorage();
    return this.articulos;
  }

  public getArticulo(index: number): Articulo {
    this.getStorage();
    return this.articulos[index];
  }

  public deleteArticulo(index: number): void {
    const articulo = this.getArticulo(index);
    this.articulos = this.articulos.filter(art => art != articulo)
    this.addStorage();
  }

  public existecodigo(codigo: number): boolean {
    let isCodigo = false;
    this.getStorage()
    let articulo = this.articulos.find(art => art.codigo == codigo);
    articulo ? isCodigo = true : isCodigo = false;
    return isCodigo;
  }

}
