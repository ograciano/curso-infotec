import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-body-blog',
  templateUrl: './body-blog.component.html',
  styleUrls: ['./body-blog.component.css']
})
export class BodyBlogComponent implements OnInit {

  constructor() { }

  titulo1: string = 'Curso HTML';
  subtitulo1: string = 'Etiquetas';
  titulo2: string = 'Curso CSS';
  subtitulo2: string = 'Bootstrap';
  titulo3: string = 'Curso Java';
  subtitulo3: string = 'Listas';
  titulo4: string = 'Cusrso Spring';
  subtitulo4: string = 'Rest COntroller';

  ngOnInit(): void {
  }

}
