import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { BodyBlogComponent } from './body-blog/body-blog.component';
import { HeaderComponent } from './header/header.component';
import { CardComponent } from './card/card.component';
import { FooterComponent } from './footer/footer.component';
import { ModalComponent } from './modal/modal.component';

@NgModule({
  declarations: [
    NavMenuComponent,
    BodyBlogComponent,
    HeaderComponent,
    CardComponent,
    FooterComponent,
    ModalComponent
  ],
  imports: [
    CommonModule,
  ],
  exports: [
    NavMenuComponent,
    BodyBlogComponent,
    HeaderComponent,
    CardComponent,
    FooterComponent,
    ModalComponent
  ]
})
export class PagesModule { }
