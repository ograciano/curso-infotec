import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  nombre: string = 'Oscar Omar';
  saldo: number = 100.50;
  dias = ['domingo', 'lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado'];
  articulos = [
    { codigo: 1, descripcion: 'papas', precio: 12.33 },
    { codigo: 2, descripcion: 'manzanas', precio: 54 },
    { codigo: 3, descripcion: 'peras', precio: 20 },
  ];
  fechaActual = new Date();
}
