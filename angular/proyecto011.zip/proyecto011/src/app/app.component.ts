import { Component, OnInit } from '@angular/core';
import { ArticulosService } from './articulos.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  public articulos: any[] = [];
  constructor(private readonly articulosService: ArticulosService){}
  ngOnInit(): void {
    this.articulosService.response().subscribe( res => {
      this.articulos = res;
    })
  }
}
